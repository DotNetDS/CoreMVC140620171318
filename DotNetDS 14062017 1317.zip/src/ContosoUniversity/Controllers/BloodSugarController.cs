using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using ContosoUniversity.Data;
using ContosoUniversity.Models;

namespace ContosoUniversity.Controllers
{
    public class BloodSugarController : Controller
    {
        private readonly ApplicationDbContext _context;

        public BloodSugarController(ApplicationDbContext context)
        {
            _context = context;    
        }

        // GET: BloodSugar
        public async Task<IActionResult> Index(string sortOrder,string currentFilter,string searchString,int? page)
        {
            ViewData["CurrentSort"] = sortOrder;

            ViewData["ValueSortParm"] = String.IsNullOrEmpty(sortOrder) ? "value" : "";
            ViewData["DateSortParm"] = sortOrder == "Date" ? "date_desc" : "Date";

            if (searchString != null)
            {
                page = 1;
            }
            else
            {
                searchString = currentFilter;
            }
            ViewData["CurrentFilter"] = searchString;

            var values = from s in _context.BloodSugar
                           select s;
            if (!String.IsNullOrEmpty(searchString))
            {
                values = values.Where(s => s.ID != 0);
            }

            switch (sortOrder)
            {
                case "Date":
                    values = values.OrderBy(s => s.DateTime);
                    break;
                case "Value":
                    values = values.OrderByDescending(s => s.Value);
                    break;
                default:
                    //values = values.OrderBy(s => s.ID);
                    values = values.OrderBy(s => s.DateTime);
                    break;
            }
            int pageSize = 3;
            return View(await PaginatedList<BloodSugar>.CreateAsync(values.AsNoTracking(), page ?? 1, pageSize));
        }

        // GET: BloodSugar/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var bloodsugar = await _context.BloodSugar.Include(cc=>cc.Value).
            AsNoTracking()
            .SingleOrDefaultAsync(m => m.ID == id);
            if (bloodsugar == null)
            {
                return NotFound();
            }

            return View(bloodsugar);
        }

        // GET: BloodSugar/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: BloodSugar/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Date,Value")] BloodSugar bloodsugar)
        {
            try { 
            if (ModelState.IsValid)
            {
                _context.Add(bloodsugar);
                await _context.SaveChangesAsync();
                return RedirectToAction("Index");
            }
            }
            catch
             (DbUpdateException  ex )
            {
                //Log the error (uncomment ex variable name and write a log.
                ModelState.AddModelError("", "Unable to save changes. " +
                    "Try again, and if the problem persists " +
                    "see your system administrator.");
            }

            return View(bloodsugar);
        }



        // GET: BloodSugar/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var valueToUpdate = await _context.BloodSugar.SingleOrDefaultAsync(m => m.ID == id);
            //if (await TryUpdateModelAsync<BloodSugar>(
            //     studentToUpdate,
            //     "",
            //     s => s.FirstMidName, s => s.LastName, s => s.EnrollmentDate))
            //{
            //    try
            //    {
            //        await _context.SaveChangesAsync();
            //        return RedirectToAction("Index");
            //    }
            //    catch (DbUpdateException /* ex */)
            //    {
            //        //Log the error (uncomment ex variable name and write a log.)
            //        ModelState.AddModelError("", "Unable to save changes. " +
            //            "Try again, and if the problem persists, " +
            //            "see your system administrator.");
            //    }
            //}
            return View(valueToUpdate);

        }

        // POST: BloodSugar/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("ID,Date,Value")] BloodSugar bloodsugar)
        {
            if (id != bloodsugar.ID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(bloodsugar);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!BloodSugarExists(bloodsugar.ID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction("Index");
            }
            return View(bloodsugar);
        }

        // GET: BloodSugar/Delete/5
        public async Task<IActionResult> Delete(int? id, bool? saveChangesError = false)
        {

           
                if (id == null)
            {
                return NotFound();
            }

            var bloodsugar = await _context.BloodSugar.AsNoTracking().SingleOrDefaultAsync(m => m.ID == id);
            if (bloodsugar == null)
            {
                return NotFound();
            }
            if (saveChangesError.GetValueOrDefault())
            {
                ViewData["ErrorMessage"] =
                    "Delete failed. Try again, and if the problem persists " +
                    "see your system administrator.";
            }



            return View(bloodsugar);
        }

        // POST: BloodSugar/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var value = await _context.BloodSugar.AsNoTracking()
.SingleOrDefaultAsync(m => m.ID == id);
            if (value == null)
            {
                return RedirectToAction("Index");
            }

            try
            {

                _context.BloodSugar.Remove(value);
                await _context.SaveChangesAsync();
                return RedirectToAction("Index");
            }
            catch (DbUpdateException /* ex */)
            {
                //Log the error (uncomment ex variable name and write a log.)
                return RedirectToAction("Delete", new { id = id, saveChangesError = true });
            }

        }

        private bool BloodSugarExists(int id)
        {
            return _context.BloodSugar.Any(e => e.ID == id);
        }
        public IActionResult DateTimePicker()
        {
            return View();
        }
    }
}
